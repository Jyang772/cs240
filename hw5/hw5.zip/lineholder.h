//Justin Yang

char *init_lineholder(int nlines);
void insert_line(char *line);
void print_lines();
